// RPCore native HUD -- shared state and the entry points Lua calls.
//
// Lua (client/native_hud.lua) hands plain values (Float / String / Bool / Int32) to the
// global functions at the bottom of this file through Open77.rtti.call. They only STORE
// values; widgets are touched later, from the HUD controller's own tick
// (RPCoreHudBars.reds), never from inside the call. That keeps whatever frame the call
// arrives on trivial. (Open77's ScriptBridge documents that native code must not run
// scripted logic without a script frame; whether rtti.call provides one is UNVERIFIED --
// see docs/NATIVE-HUD.md "Risks".)
//
// Nothing in this pack edits or replaces any Open77 file, and no Open77 symbol is
// referenced, so the pack compiles with or without Open77's scripts present.

public class RPCoreHudSystem extends ScriptableSystem {
  public let revision: Int32;       // bumped on every state push; controllers re-apply on change
  public let tickCounter: Int32;    // +1 per controller tick (0.25 s real time)
  public let lastPushTick: Int32;   // tickCounter at the last push or heartbeat
  public let generation: Int32;     // newest controller owns the tick loop
  public let attached: Bool;
  public let cleared: Bool;

  public let hungerVisible: Bool;
  public let hungerValue: Float;
  public let hungerMax: Float;
  public let thirstVisible: Bool;
  public let thirstValue: Float;
  public let thirstMax: Float;
  public let psyVisible: Bool;
  public let psyValue: Float;
  public let psyMax: Float;
  public let tier: Int32;           // 1 stable .. 5 psychosis

  public let bounds: array<Float>;  // inner tier boundaries as fractions of max (4 values)
  public let labels: array<String>;
  public let hungerLabel: String;
  public let thirstLabel: String;
  public let psyLabel: String;
  public let relicEnabled: Bool;
  public let relicRecord: String;
  public let fxName: CName;

  public let relicApplied: Bool;
  public let relicSuppressed: Bool;
  public let blackwallState: String; // unknown | present | absent
}

public static func RPCoreHudSystemGet() -> ref<RPCoreHudSystem> {
  return GameInstance.GetScriptableSystemsContainer(GetGameInstance()).Get(n"RPCoreHudSystem") as RPCoreHudSystem;
}

// Returns false if the system cannot be reached from this call context -- Lua reports it.
public static func RPCoreHudPing() -> Bool {
  return IsDefined(RPCoreHudSystemGet());
}

public static func RPCoreHudConfigure(
  bounds: String, labels: String, relicEnabled: Bool, relicRecord: String,
  fxName: String, psychosisLabel: String, hungerLabel: String, thirstLabel: String
) -> Bool {
  let system: ref<RPCoreHudSystem> = RPCoreHudSystemGet();
  if !IsDefined(system) { return false; }
  ArrayClear(system.bounds);
  ArrayClear(system.labels);
  let parts: array<String> = StrSplit(bounds, ",");
  let i: Int32 = 0;
  while i < ArraySize(parts) {
    ArrayPush(system.bounds, StringToFloat(parts[i]));
    i += 1;
  }
  parts = StrSplit(labels, ",");
  i = 0;
  while i < ArraySize(parts) {
    ArrayPush(system.labels, parts[i]);
    i += 1;
  }
  system.relicEnabled = relicEnabled;
  system.relicRecord = relicRecord;
  system.fxName = StringToName(fxName);
  system.psyLabel = psychosisLabel;
  system.hungerLabel = hungerLabel;
  system.thirstLabel = thirstLabel;
  system.relicSuppressed = false;
  system.revision += 1;
  system.lastPushTick = system.tickCounter;
  return true;
}

public static func RPCoreHudSetBar(bar: String, visible: Bool, value: Float, max: Float) -> Bool {
  let system: ref<RPCoreHudSystem> = RPCoreHudSystemGet();
  if !IsDefined(system) || max <= 0.0 { return false; }
  if Equals(bar, "hunger") {
    system.hungerVisible = visible;
    system.hungerValue = ClampF(value, 0.0, max);
    system.hungerMax = max;
  } else if Equals(bar, "thirst") {
    system.thirstVisible = visible;
    system.thirstValue = ClampF(value, 0.0, max);
    system.thirstMax = max;
  } else {
    return false;
  }
  system.cleared = false;
  system.revision += 1;
  system.lastPushTick = system.tickCounter;
  return true;
}

public static func RPCoreHudSetPsychosis(visible: Bool, value: Float, max: Float, tier: Int32) -> Bool {
  let system: ref<RPCoreHudSystem> = RPCoreHudSystemGet();
  if !IsDefined(system) || max <= 0.0 { return false; }
  system.psyVisible = visible;
  system.psyValue = ClampF(value, 0.0, max);
  system.psyMax = max;
  system.tier = tier < 1 ? 1 : (tier > 5 ? 5 : tier);
  system.cleared = false;
  system.revision += 1;
  system.lastPushTick = system.tickCounter;
  return true;
}

public static func RPCoreHudHeartbeat() -> Bool {
  let system: ref<RPCoreHudSystem> = RPCoreHudSystemGet();
  if !IsDefined(system) { return false; }
  system.lastPushTick = system.tickCounter;
  return true;
}

// Hide every RPCore bar and drop every effect (resource stop, bridge disabled).
public static func RPCoreHudClear() -> Bool {
  let system: ref<RPCoreHudSystem> = RPCoreHudSystemGet();
  if !IsDefined(system) { return false; }
  system.cleared = true;
  system.hungerVisible = false;
  system.thirstVisible = false;
  system.psyVisible = false;
  system.tier = 1;
  system.revision += 1;
  return true;
}

// "k=v;k=v" for Lua to log. relic: off | applied | suppressed | disabled.
public static func RPCoreHudStatus() -> String {
  let system: ref<RPCoreHudSystem> = RPCoreHudSystemGet();
  if !IsDefined(system) { return "attached=0;system=unreachable"; }
  let relic: String = "off";
  if !system.relicEnabled || StrLen(system.relicRecord) == 0 { relic = "disabled"; }
  else if system.relicSuppressed { relic = "suppressed"; }
  else if system.relicApplied { relic = "applied"; }
  let stale: Bool = system.revision > 0 && system.tickCounter - system.lastPushTick > 60;
  return "attached=" + (system.attached ? "1" : "0")
    + ";tier=" + IntToString(system.tier)
    + ";relic=" + relic
    + ";blackwall=" + (StrLen(system.blackwallState) > 0 ? system.blackwallState : "unknown")
    + ";stale=" + (stale ? "1" : "0")
    + ";rev=" + IntToString(system.revision);
}
