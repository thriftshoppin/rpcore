// RPCore native HUD -- hunger / thirst / cyberpsychosis bars on the game's own HUD.
//
// Wraps healthbarWidgetGameController with @wrapMethod / @addField / @addMethod and adds a
// container of bars as a SIBLING of the vanilla health bar (same anchor, stacked next to it).
// COOPERATIVE: every wrapper calls wrappedMethod() first and returns its result; no vanilla
// widget is hidden, moved or restyled; nothing assumes this is the only wrapper. Open77
// wraps the same controller (OnInitialize / OnUpdateHealthBarVisibility), and redscript
// chains wrappers, so both run.
//
// STYLE: colours/sizes below are APPROXIMATIONS of the vanilla look. The WolvenKit JSON
// exports and screenshots this was meant to match were not in the upload, so nothing here
// is traced from them. Tune the RPCoreHud* layout functions after seeing it in game.
//
// NOT COMPILED OR RUN. See docs/NATIVE-HUD.md for what is untested.

// ---- layout / style knobs (redscript has no constants; these are functions) ------------
public static func RPCoreHudBarWidth() -> Float { return 260.0; }
public static func RPCoreHudBarThickness() -> Float { return 8.0; }
public static func RPCoreHudBlockHeight() -> Float { return 30.0; }
public static func RPCoreHudGap() -> Float { return 14.0; }
public static func RPCoreHudOffsetX() -> Float { return 0.0; }
public static func RPCoreHudFallbackRootHeight() -> Float { return 60.0; }
// How many ancestors above the vanilla health bar a Breach/Psychosis Blackwall effect covers.
public static func RPCoreHudBreachClimb() -> Int32 { return 2; }
public static func RPCoreHudStaleTicks() -> Int32 { return 60; }   // 15 s without a push or heartbeat

public static func RPCoreHudColorHunger() -> HDRColor { return new HDRColor(1.2, 0.8, 0.25, 1.0); }
public static func RPCoreHudColorThirst() -> HDRColor { return new HDRColor(0.368, 0.964, 1.0, 1.0); }
public static func RPCoreHudColorPsychosis(tier: Int32) -> HDRColor {
  if tier >= 4 { return new HDRColor(1.5, 0.1, 0.1, 1.0); }
  if tier >= 2 { return new HDRColor(1.4, 0.2, 0.15, 1.0); }
  return new HDRColor(1.1761, 0.3809, 0.3476, 1.0);
}

public class RPCoreBar extends IScriptable {
  public let root: ref<inkCanvas>;
  public let label: ref<inkText>;
  public let background: ref<inkRectangle>;
  public let fill: ref<inkRectangle>;
  public let ticks: array<ref<inkRectangle>>;
  public let shown: Bool;
}

public class RPCoreHudTick extends DelayCallback {
  public let game: GameInstance;
  public let controller: wref<healthbarWidgetGameController>;
  public let generation: Int32;

  public func Call() -> Void {
    if !IsDefined(this.controller) { return; }   // controller gone: the loop simply ends
    this.controller.RPCoreTick(this.game, this.generation);
  }
}

@addField(healthbarWidgetGameController) private let m_rpcContainer: ref<inkCanvas>;
@addField(healthbarWidgetGameController) private let m_rpcBars: array<ref<RPCoreBar>>;  // 0 hunger, 1 thirst, 2 psychosis
@addField(healthbarWidgetGameController) private let m_rpcAttached: Bool;
@addField(healthbarWidgetGameController) private let m_rpcGeneration: Int32;
@addField(healthbarWidgetGameController) private let m_rpcRevision: Int32;
@addField(healthbarWidgetGameController) private let m_rpcTier: Int32;
@addField(healthbarWidgetGameController) private let m_rpcStale: Bool;
@addField(healthbarWidgetGameController) private let m_rpcRelicTried: Bool;
@addField(healthbarWidgetGameController) private let m_rpcRelicCheck: Int32;

// ---- cooperative wrappers (the only two Open77 also wraps; both proven to chain) ------
@wrapMethod(healthbarWidgetGameController)
protected cb func OnInitialize() -> Bool {
  let result: Bool = wrappedMethod();
  this.m_rpcRevision = -1;
  this.m_rpcTier = 0;
  this.RPCoreBuild();
  this.RPCoreAttach();
  return result;
}

@wrapMethod(healthbarWidgetGameController)
protected cb func OnUpdateHealthBarVisibility() -> Bool {
  let result: Bool = wrappedMethod();
  this.RPCoreAttach();   // the player is not always attached during OnInitialize
  return result;
}

// ---- construction ----------------------------------------------------------------------
@addMethod(healthbarWidgetGameController)
private func RPCoreMakeBar(parent: ref<inkCompoundWidget>, name: CName, color: HDRColor) -> ref<RPCoreBar> {
  let width: Float = RPCoreHudBarWidth();
  let thickness: Float = RPCoreHudBarThickness();
  let bar: ref<RPCoreBar> = new RPCoreBar();

  bar.root = parent.AddChild(n"inkCanvasWidget") as inkCanvas;
  bar.root.SetName(name);
  bar.root.SetAnchor(inkEAnchor.TopLeft);
  bar.root.SetAnchorPoint(Vector2(0.0, 0.0));
  bar.root.SetSize(width, RPCoreHudBlockHeight());
  bar.root.SetInteractive(false);
  bar.root.SetVisible(false);

  bar.label = bar.root.AddChild(n"inkTextWidget") as inkText;
  bar.label.SetName(n"label");
  bar.label.SetFontFamily("base\\gameplay\\gui\\fonts\\raj\\raj.inkfontfamily", n"Medium");
  bar.label.SetFontSize(18);
  bar.label.SetAnchor(inkEAnchor.TopLeft);
  bar.label.SetMargin(0.0, 0.0, 0.0, 0.0);
  bar.label.SetTintColor(new HDRColor(0.92, 0.96, 0.98, 0.95));
  bar.label.SetText("");

  bar.background = bar.root.AddChild(n"inkRectangleWidget") as inkRectangle;
  bar.background.SetName(n"background");
  bar.background.SetAnchor(inkEAnchor.TopLeft);
  bar.background.SetMargin(0.0, 20.0, 0.0, 0.0);
  bar.background.SetSize(width, thickness);
  bar.background.SetTintColor(new HDRColor(0.025, 0.045, 0.06, 0.6));

  bar.fill = bar.root.AddChild(n"inkRectangleWidget") as inkRectangle;
  bar.fill.SetName(n"fill");
  bar.fill.SetAnchor(inkEAnchor.TopLeft);
  bar.fill.SetMargin(0.0, 20.0, 0.0, 0.0);
  bar.fill.SetSize(0.0, thickness);
  bar.fill.SetTintColor(color);
  return bar;
}

@addMethod(healthbarWidgetGameController)
private func RPCoreBuild() -> Void {
  if IsDefined(this.m_rpcContainer) { return; }
  let root: ref<inkWidget> = this.GetRootWidget();
  if !IsDefined(root) { return; }

  // Sibling of the vanilla bar so Open77 hiding / the game's contextual fade of the vanilla
  // root does not take RPCore's bars with it. Fall back to a child of the root if needed.
  let parent: ref<inkCompoundWidget> = root.parentWidget as inkCompoundWidget;
  let asChild: Bool = false;
  if !IsDefined(parent) {
    parent = this.GetRootCompoundWidget();
    asChild = true;
  }
  if !IsDefined(parent) { return; }

  this.m_rpcContainer = parent.AddChild(n"inkCanvasWidget") as inkCanvas;
  this.m_rpcContainer.SetName(n"RPCoreVitals");
  this.m_rpcContainer.SetInteractive(false);
  this.m_rpcContainer.SetVisible(false);
  this.m_rpcContainer.SetSize(RPCoreHudBarWidth(), RPCoreHudBlockHeight() * 3.0);

  let rootHeight: Float = root.GetHeight();
  if rootHeight < 10.0 { rootHeight = RPCoreHudFallbackRootHeight(); }
  let gap: Float = RPCoreHudGap();
  let offsetX: Float = RPCoreHudOffsetX();
  if asChild {
    // Child of the vanilla root: coordinates are relative to it. Hang the bars under it.
    this.m_rpcContainer.SetAnchor(inkEAnchor.TopLeft);
    this.m_rpcContainer.SetAnchorPoint(Vector2(0.0, 0.0));
    this.m_rpcContainer.SetMargin(offsetX, rootHeight + gap, 0.0, 0.0);
  } else {
    // Same anchor as the vanilla bar, pushed past it: up if it hangs from the bottom,
    // down otherwise. Heuristic -- confirm the direction in game.
    let anchor: inkEAnchor = root.GetAnchor();
    let margin: inkMargin = root.GetMargin();
    this.m_rpcContainer.SetAnchor(anchor);
    this.m_rpcContainer.SetAnchorPoint(root.GetAnchorPoint());
    if Equals(anchor, inkEAnchor.BottomLeft) || Equals(anchor, inkEAnchor.BottomCenter) || Equals(anchor, inkEAnchor.BottomRight) {
      margin.bottom += rootHeight + gap;
    } else {
      margin.top += rootHeight + gap;
    }
    margin.left += offsetX;
    this.m_rpcContainer.SetMargin(margin);
  }

  ArrayClear(this.m_rpcBars);
  ArrayPush(this.m_rpcBars, this.RPCoreMakeBar(this.m_rpcContainer, n"RPCoreHunger", RPCoreHudColorHunger()));
  ArrayPush(this.m_rpcBars, this.RPCoreMakeBar(this.m_rpcContainer, n"RPCoreThirst", RPCoreHudColorThirst()));
  ArrayPush(this.m_rpcBars, this.RPCoreMakeBar(this.m_rpcContainer, n"RPCoreCyberpsychosis", RPCoreHudColorPsychosis(1)));

  // Tier tick marks on the cyberpsychosis bar (4 inner boundaries, positioned on apply).
  let i: Int32 = 0;
  while i < 4 {
    let tick: ref<inkRectangle> = this.m_rpcBars[2].root.AddChild(n"inkRectangleWidget") as inkRectangle;
    tick.SetName(n"tick");
    tick.SetAnchor(inkEAnchor.TopLeft);
    tick.SetSize(2.0, RPCoreHudBarThickness() + 4.0);
    tick.SetTintColor(new HDRColor(1.0, 1.0, 1.0, 0.85));
    tick.SetVisible(false);
    ArrayPush(this.m_rpcBars[2].ticks, tick);
    i += 1;
  }
}

// ---- attach + tick loop ----------------------------------------------------------------
@addMethod(healthbarWidgetGameController)
public func RPCoreAttach() -> Void {
  if this.m_rpcAttached { return; }
  let player: ref<GameObject> = this.GetPlayerControlledObject() as GameObject;
  if !IsDefined(player) { return; }
  let game: GameInstance = player.GetGame();
  let system: ref<RPCoreHudSystem> = GameInstance.GetScriptableSystemsContainer(game).Get(n"RPCoreHudSystem") as RPCoreHudSystem;
  if !IsDefined(system) { return; }
  this.m_rpcAttached = true;
  system.attached = true;
  system.generation += 1;            // any older controller's loop stops at its next tick
  this.m_rpcGeneration = system.generation;
  // A previous controller may have left the relic effect on: this one starts clean.
  if system.relicApplied && IsDefined(player) && StrLen(system.relicRecord) > 0 {
    StatusEffectHelper.RemoveStatusEffect(player, TDBID.Create(system.relicRecord));
    system.relicApplied = false;
  }
  this.RPCoreSchedule(game);
}

@addMethod(healthbarWidgetGameController)
private func RPCoreSchedule(game: GameInstance) -> Void {
  let tick: ref<RPCoreHudTick> = new RPCoreHudTick();
  tick.game = game;
  tick.controller = this;
  tick.generation = this.m_rpcGeneration;
  // false: real-time, so effects still lapse during slow motion or a frozen sim clock.
  GameInstance.GetDelaySystem(game).DelayCallback(tick, 0.25, false);
}

@addMethod(healthbarWidgetGameController)
public func RPCoreTick(game: GameInstance, generation: Int32) -> Void {
  let system: ref<RPCoreHudSystem> = GameInstance.GetScriptableSystemsContainer(game).Get(n"RPCoreHudSystem") as RPCoreHudSystem;
  if !IsDefined(system) || system.generation != generation { return; }
  system.tickCounter += 1;
  this.RPCoreApply(system);
  this.RPCoreSchedule(game);          // unconditional: one failure must not end the loop
}

// ---- apply state -----------------------------------------------------------------------
@addMethod(healthbarWidgetGameController)
private func RPCoreApplyOne(bar: ref<RPCoreBar>, visible: Bool, value: Float, max: Float, label: String) -> Void {
  if !IsDefined(bar) || !IsDefined(bar.root) { return; }
  bar.shown = visible;
  bar.root.SetVisible(visible);
  if !visible { return; }
  let fraction: Float = max > 0.0 ? ClampF(value / max, 0.0, 1.0) : 0.0;
  bar.fill.SetSize(RPCoreHudBarWidth() * fraction, RPCoreHudBarThickness());
  bar.label.SetText(label + "  " + IntToString(FloorF(value)));
}

@addMethod(healthbarWidgetGameController)
private func RPCoreApplyBars(system: ref<RPCoreHudSystem>, tier: Int32) -> Void {
  let hunger: String = StrLen(system.hungerLabel) > 0 ? system.hungerLabel : "HUNGER";
  let thirst: String = StrLen(system.thirstLabel) > 0 ? system.thirstLabel : "THIRST";
  let psy: String = StrLen(system.psyLabel) > 0 ? system.psyLabel : "CYBERPSYCHOSIS";
  if tier >= 1 && tier <= ArraySize(system.labels) {
    let tierName: String = system.labels[tier - 1];
    if StrLen(tierName) > 0 { psy = psy + " / " + StrUpper(tierName); }
  }

  this.RPCoreApplyOne(this.m_rpcBars[0], system.hungerVisible && !system.cleared, system.hungerValue, system.hungerMax, hunger);
  this.RPCoreApplyOne(this.m_rpcBars[1], system.thirstVisible && !system.cleared, system.thirstValue, system.thirstMax, thirst);
  this.RPCoreApplyOne(this.m_rpcBars[2], system.psyVisible && !system.cleared, system.psyValue, system.psyMax, psy);
  this.m_rpcBars[2].fill.SetTintColor(RPCoreHudColorPsychosis(tier));

  // Tier ticks at the configured boundaries.
  let i: Int32 = 0;
  while i < ArraySize(this.m_rpcBars[2].ticks) {
    let tick: ref<inkRectangle> = this.m_rpcBars[2].ticks[i];
    if i < ArraySize(system.bounds) {
      tick.SetMargin(RPCoreHudBarWidth() * system.bounds[i] - 1.0, 18.0, 0.0, 0.0);
      tick.SetVisible(true);
    } else {
      tick.SetVisible(false);
    }
    i += 1;
  }

  // Stack the visible bars without gaps and show the container only if one is visible.
  let y: Float = 0.0;
  let any: Bool = false;
  i = 0;
  while i < ArraySize(this.m_rpcBars) {
    if this.m_rpcBars[i].shown {
      this.m_rpcBars[i].root.SetMargin(0.0, y, 0.0, 0.0);
      y += RPCoreHudBlockHeight();
      any = true;
    }
    i += 1;
  }
  this.m_rpcContainer.SetVisible(any);
}

@addMethod(healthbarWidgetGameController)
private func RPCoreApply(system: ref<RPCoreHudSystem>) -> Void {
  if !IsDefined(this.m_rpcContainer) || ArraySize(this.m_rpcBars) < 3 { return; }

  // Crash safety: if Lua stops pushing (resource stopped, mission/provider crashed, feed
  // dead) every effect drops to Stable after ~15 s. Bars keep their last values.
  let stale: Bool = system.revision > 0 && system.tickCounter - system.lastPushTick > RPCoreHudStaleTicks();
  let tier: Int32 = system.tier < 1 ? 1 : system.tier;
  if stale || system.cleared { tier = 1; }

  if system.revision != this.m_rpcRevision || tier != this.m_rpcTier {
    this.m_rpcRevision = system.revision;
    this.RPCoreApplyBars(system, tier);
  }
  if tier != this.m_rpcTier || (stale ? 1 : 0) != (this.m_rpcStale ? 1 : 0) {
    // First pass at Stable touches no effects at all: never switch off something the vanilla
    // widgets might own under the same name.
    let first: Bool = this.m_rpcTier == 0;
    this.m_rpcTier = tier;
    this.m_rpcStale = stale;
    if !first || tier > 1 { this.RPCoreApplyFx(system, tier); }
  }
  this.RPCoreRelicStep(system, tier);
}

// ---- tier effects (the game's own: ink effects + status effects) -----------------------
@addMethod(healthbarWidgetGameController)
private func RPCoreSetBlackwall(system: ref<RPCoreHudSystem>, widget: ref<inkWidget>, level: Float) -> Void {
  if !IsDefined(widget) || !IsNameValid(system.fxName) { return; }
  if level > 0.0 {
    widget.SetEffectParamValue(inkEffectType.Glitch, system.fxName, n"intensity", level);
    widget.SetEffectEnabled(inkEffectType.Glitch, system.fxName, true);
    // Presence probe: an inkBlackwallEffect that is not on the widget cannot hold a value.
    let held: Float = widget.GetEffectParamValue(inkEffectType.Glitch, system.fxName, n"intensity");
    system.blackwallState = AbsF(held - level) < 0.02 ? "present" : "absent";
  } else {
    widget.SetEffectEnabled(inkEffectType.Glitch, system.fxName, false);
  }
}

@addMethod(healthbarWidgetGameController)
private func RPCoreApplyFx(system: ref<RPCoreHudSystem>, tier: Int32) -> Void {
  let psy: ref<RPCoreBar> = this.m_rpcBars[2];

  // Strained and up: tint (RPCoreApplyBars) + light flicker on the cyberpsychosis bar.
  psy.root.StopAllAnimations();
  psy.root.SetOpacity(1.0);
  if tier >= 2 {
    let def: ref<inkAnimDef> = new inkAnimDef();
    let flicker: ref<inkAnimTransparency> = new inkAnimTransparency();
    flicker.SetStartTransparency(1.0);
    flicker.SetEndTransparency(tier >= 3 ? 0.5 : 0.7);
    flicker.SetDuration(tier >= 3 ? 0.14 : 0.3);
    flicker.SetType(inkanimInterpolationType.Linear);
    flicker.SetMode(inkanimInterpolationMode.EasyInOut);
    def.AddInterpolator(flicker);
    psy.root.PlayAnimationWithOptions(def, GetAnimOptionsInfiniteLoop(inkanimLoopType.PingPong));
  }

  // Fraying: inkBlackwallEffect on the vitals bars. Breach/Psychosis: heavier, and across
  // the HUD (the vanilla bar and its ancestors). Disabling always walks the full set.
  let level: Float = 0.0;
  if tier == 3 { level = 0.45; }
  else if tier == 4 { level = 0.8; }
  else if tier >= 5 { level = 1.0; }

  let own: Float = level;
  this.RPCoreSetBlackwall(system, this.m_rpcContainer, own);
  let i: Int32 = 0;
  while i < ArraySize(this.m_rpcBars) {
    this.RPCoreSetBlackwall(system, this.m_rpcBars[i].root, own);
    i += 1;
  }

  let heavy: Float = tier >= 4 ? level : 0.0;
  let widget: ref<inkWidget> = this.GetRootWidget();
  let climbed: Int32 = 0;
  while IsDefined(widget) && climbed <= RPCoreHudBreachClimb() {
    this.RPCoreSetBlackwall(system, widget, heavy);
    widget = widget.parentWidget;
    climbed += 1;
  }
}

@addMethod(healthbarWidgetGameController)
private func RPCoreRelicStep(system: ref<RPCoreHudSystem>, tier: Int32) -> Void {
  let player: ref<GameObject> = this.GetPlayerControlledObject() as GameObject;
  if !IsDefined(player) || StrLen(system.relicRecord) == 0 { return; }
  let id: TweakDBID = TDBID.Create(system.relicRecord);
  let want: Bool = tier >= 5 && system.relicEnabled && !system.relicSuppressed;

  if tier < 5 {
    system.relicSuppressed = false;   // a later entry into Psychosis gets one fresh attempt
    this.m_rpcRelicTried = false;
  }
  if want && !system.relicApplied && !this.m_rpcRelicTried {
    StatusEffectHelper.ApplyStatusEffect(player, id);
    system.relicApplied = true;
    this.m_rpcRelicTried = true;
    this.m_rpcRelicCheck = 2;          // look again in ~0.5 s
    return;
  }
  if system.relicApplied && this.m_rpcRelicCheck > 0 {
    this.m_rpcRelicCheck -= 1;
    if this.m_rpcRelicCheck == 0 {
      // Open77's multiplayer policy removes Johnny-sickness effects the moment they apply.
      // Detect that by behaviour (no Open77 symbol needed): applied, then gone.
      let present: Bool = StatusEffectSystem.ObjectHasStatusEffect(player, id);
      if !present {
        system.relicSuppressed = true;
        system.relicApplied = false;
      }
    }
    return;
  }
  if !want && system.relicApplied {
    StatusEffectHelper.RemoveStatusEffect(player, id);
    system.relicApplied = false;
  }
}
